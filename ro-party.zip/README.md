# RO 糾團佈告欄（Cloudflare Pages 版）

免登入的 RO 自動組團小工具。前端為靜態頁面，資料透過同網域的 `/api`（Cloudflare Pages Functions）存取 **D1 資料庫**——資料庫完全不暴露在前端，遊戲規則（等級門檻、時段、次數上限）都在伺服器端再驗證一次，且退團需要登記時發放、只存在登記者瀏覽器的憑證，從根本杜絕惡意幫別人退團。

程式碼放 GitHub，push 即自動部署（Cloudflare Pages 內建 CI/CD），全部免費方案即可運行。

## 專案結構

```
ro-party/
├── public/
│   └── index.html              前端頁面
├── functions/
│   └── api/
│       ├── regs.js             GET 查詢當日登記、POST 新增（含規則驗證）
│       ├── regs/[uid].js       DELETE 退團（需 X-Token 憑證）
│       └── chats/[key].js      GET/POST 團員留言板
├── schema.sql                  D1 資料庫結構
├── wrangler.toml               Pages 設定與 D1 綁定
└── README.md
```

## 部署步驟（約 10 分鐘）

### 1. 上傳到 GitHub
建立一個 repository，把整個專案結構原樣 push 上去。

### 2. 建立 D1 資料庫
到 [Cloudflare Dashboard](https://dash.cloudflare.com) → **Storage & Databases → D1** → **Create database**，名稱填 `ro-party`。

建立後進入該資料庫的 **Console** 分頁，把 `schema.sql` 的內容整段貼上執行（會建立 `regs` 與 `chats` 兩張表）。

記下資料庫的 **Database ID**，回到專案把 `wrangler.toml` 裡的 `database_id` 換成它，commit + push。

> 若你習慣用命令列，也可以：
> ```bash
> npx wrangler d1 create ro-party
> npx wrangler d1 execute ro-party --file=schema.sql --remote
> ```

### 3. 建立 Pages 專案（連接 GitHub = CI/CD）
Dashboard → **Workers & Pages → Create → Pages → Connect to Git**，選你的 repository。

Build 設定：
- Framework preset：**None**
- Build command：留空
- Build output directory：`public`

按下 Deploy。之後**每次 push 到 GitHub，Cloudflare 會自動重新部署**，這就是內建的 CI/CD。

### 4. 確認 D1 綁定
`wrangler.toml` 已宣告綁定，通常部署時會自動生效。若 API 回 500，到 Pages 專案 → **Settings → Bindings** 手動確認有一筆 D1 綁定：Variable name `DB` → 選 `ro-party` 資料庫，重新部署一次。

### 5. 完成
網站會在 `https://你的專案.pages.dev` 上線（可再綁自己的網域）。頁面右上顯示「共用模式」代表 API 連線正常。

## 安全性說明（誠實版）

這個架構保護了什麼、沒保護什麼，說清楚比較好：

**有保護：**
- 資料庫連線資訊、憑證完全在後端，前端原始碼裡沒有任何秘密。
- 退團需要 token（登記當下發放、只存在登記者的瀏覽器），別人知道你的角色 ID 也刪不了你的登記。
- 等級門檻、時段規則、每角色每日登記上限（20 次）都在伺服器端強制執行，改前端程式碼繞不過。
- 留言與各欄位長度都有上限，防止塞垃圾資料。

**沒保護（本質限制）：**
- 這是免登入的公開工具，`/api` 端點任何人都能呼叫，有心人仍可寫程式灌假登記。每日次數上限能擋掉大部分濫用；若日後真的被騷擾，可在 Cloudflare 免費啟用 **Turnstile**（無感驗證碼）加到登記 API 上，或用 WAF 規則限流。

**行為上的小改變：**
- 因為退團憑證存在登記時的瀏覽器，**退團必須用當初登記的那台裝置／瀏覽器操作**（這正是防惡意退團的代價）。
- 資料改存雲端資料庫後不會每日自動消失，但查詢一律以「當日」為範圍，舊資料不影響使用；若想定期清理，可在 D1 Console 執行 `DELETE FROM regs WHERE date < '2026-01-01';` 之類的語句。

## 本機預覽

```bash
npx wrangler pages dev public --d1 DB=ro-party
```

或直接開 `public/index.html` —— 連不上 `/api` 時會自動退回單機模式（資料只存瀏覽器），方便快速看畫面。
