-- RO 糾團佈告欄 D1 資料庫結構
CREATE TABLE IF NOT EXISTS regs (
  uid      TEXT PRIMARY KEY,
  token    TEXT NOT NULL,          -- 退團憑證，只回傳給登記者本人，絕不出現在查詢 API
  charId   TEXT NOT NULL,
  level    INTEGER NOT NULL,
  job      TEXT NOT NULL,
  activity TEXT NOT NULL,
  startHM  TEXT NOT NULL,
  endHM    TEXT NOT NULL,
  date     TEXT NOT NULL,
  bento    INTEGER DEFAULT 0,
  ts       INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_regs_date ON regs(date);

CREATE TABLE IF NOT EXISTS chats (
  id   INTEGER PRIMARY KEY AUTOINCREMENT,
  key  TEXT NOT NULL,
  name TEXT NOT NULL,
  text TEXT NOT NULL,
  ts   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chats_key ON chats(key);
